from flask import Flask, render_template, request
from keras.preprocessing.image import load_img
from keras.preprocessing.image import img_to_array
from keras.applications.vgg16 import preprocess_input
import tensorflow as tf

app = Flask(__name__)

# Replace these labels with your actual class labels
custom_labels = {
    0: 'Class1',
    1: 'Class2',
    2: 'Class3',
    # Add more class mappings as needed
}

@app.route('/', methods=['GET'])
def hello_word():
    return render_template('index.html')

@app.route('/', methods=['POST'])
def predict():
    imagefile = request.files['imagefile']
    image_path = "./images/" + imagefile.filename
    imagefile.save(image_path)
    pat = r"C:\Users\MeCra\Downloads\Telegram Desktop\CNN_BrainTumors.h5"
    model = tf.keras.models.load_model(pat)

    image = load_img(image_path, target_size=(224, 224))
    image = img_to_array(image)
    image = image.reshape((1, image.shape[0], image.shape[1], image.shape[2]))
    image = preprocess_input(image)
    yhat = model.predict(image)

    # Assuming your model predicts one class per image
    predicted_class_index = tf.argmax(yhat, axis=-1).numpy()[0]

    # Get the predicted label based on the predicted class index
    predicted_label = custom_labels.get(predicted_class_index, 'Unknown Class')

    return render_template('index.html', prediction=predicted_label)

if __name__ == '__main__':
    app.run(port=3000, debug=True)
